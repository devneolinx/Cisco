﻿function UserResponse() {
    this.answers = new Array();
}
var userResponse = new UserResponse();